export type ResourceCategory = "Scripts" | "UI" | "Key";

export type LinkvertiseStep = {
  url: string;
  ads: number;
  label?: string;
};

export type Resource = {
  slug: string;
  title: string;
  description: string;
  category: ResourceCategory;
  type: string;
  tag: string;
  color: string;
  version: string;

  /** 0 = no steps (direct key), 1+ = Linkvertise steps */
  steps: number;

  requiresKey: boolean;
  downloadUrl?: string;

  keyConfig?: {
    expiresDays?: number;
    maxUses?: number;
  };

  keyType?: "regular" | "premium";

  linkvertise?: LinkvertiseStep[];

  cover?: string;
  keyUsage?: string;
  disabled?: boolean;

  /** Script ID in the loader worker (for /get_script) */
  loaderScriptId?: string;
};

const LINKVERTISE_URL = "https://link-center.net/1343514/Hlzlwx0Sl3Eb";
const KEY_USAGE = "Paste into any NoNameHub script that requires a key.";

export const resources: Resource[] = [
  // ─── Scripts ─────────────────────────────────────────────
  {
    slug: "iwttg-v3",
    title: "I Wanna Test The Game v3",
    description:
      "Latest stable release. Full feature set, regular key required.",
    category: "Scripts",
    type: "Script",
    tag: "V3",
    color: "violet",
    version: "3.0.0",
    steps: 1,
    requiresKey: true,
    keyType: "regular",
    keyConfig: { expiresDays: 2, maxUses: 75 },
    linkvertise: [{ url: LINKVERTISE_URL, ads: 2, label: "Step 1 of 1" }],
    cover: "/IWTTG-v3-cover.webp",
    loaderScriptId: "IWTTGame_v3",
    keyUsage: KEY_USAGE,
  },
  {
    slug: "iwttg-v2",
    title: "I Wanna Test The Game v2",
    description:
      "Previous stable release. Archived for legacy compatibility.",
    category: "Scripts",
    type: "Script",
    tag: "V2",
    color: "violet",
    version: "2.0.0",
    steps: 1,
    requiresKey: true,
    keyType: "regular",
    keyConfig: { expiresDays: 2, maxUses: 75 },
    linkvertise: [{ url: LINKVERTISE_URL, ads: 2, label: "Step 1 of 1" }],
    cover: "/IWTTG-v2-cover.webp",
    loaderScriptId: "IWTTGame_v2",
    keyUsage: KEY_USAGE,
  },
  {
    slug: "iwttg-reworked-beta",
    title: "I Wanna Test The Game (Reworked Beta)",
    description: "Experimental rework. Archived — may contain bugs.",
    category: "Scripts",
    type: "Script",
    tag: "BETA",
    color: "violet",
    version: "0.62.0-beta",
    steps: 1,
    requiresKey: true,
    keyType: "regular",
    keyConfig: { expiresDays: 2, maxUses: 75 },
    linkvertise: [{ url: LINKVERTISE_URL, ads: 2, label: "Step 1 of 1" }],
    cover: "/IWTTG-beta-reworked-cover.webp",
    loaderScriptId: "IWTTGame_reworked_beta",
    keyUsage: KEY_USAGE,
  },

  // ─── Keys (universal access) ─────────────────────────────
  {
    slug: "nn-key",
    title: "Universal Access Key",
    description:
      "One key for all NoNameHub scripts. Get it once, use it everywhere.",
    category: "Key",
    type: "Key",
    tag: "KEY",
    color: "violet",
    version: "0.1.0",
    steps: 1,
    requiresKey: true,
    keyType: "regular",
    keyConfig: { expiresDays: 2, maxUses: 75 },
    linkvertise: [{ url: LINKVERTISE_URL, ads: 2, label: "Step 1 of 1" }],
    cover: "/key-cover.webp",
    keyUsage: KEY_USAGE,
  },
  {
    slug: "nn-key-premium",
    title: "Premium Access Key",
    description:
      "Premium key for advanced features. Requires completing 3 steps (2 ads each).",
    category: "Key",
    type: "Key",
    tag: "PREMIUM",
    color: "amber",
    version: "0.1.0",
    steps: 3,
    requiresKey: true,
    keyType: "premium",
    keyConfig: { expiresDays: 2, maxUses: 35 },
    linkvertise: [
      { url: LINKVERTISE_URL, ads: 2, label: "Step 1 of 3" },
      { url: LINKVERTISE_URL, ads: 2, label: "Step 2 of 3" },
      { url: LINKVERTISE_URL, ads: 2, label: "Step 3 of 3" },
    ],
    cover: "/key-cover-premium.webp",
    keyUsage: KEY_USAGE,
  },
];