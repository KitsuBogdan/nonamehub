import { ImageResponse } from "next/og";
import { readFile } from "fs/promises";
import path from "path";
import { SITE } from "@/data/site";

export const alt = "NoNameHub — Roblox resource hub";
export const size = { width: 1200, height: 630 };
export const contentType = "image/webp";

async function getLogoDataUri(): Promise<string | null> {
  try {
    const filePath = path.join(process.cwd(), "public", "logo.webp");
    const buf = await readFile(filePath);
    return `data:image/webp;base64,${buf.toString("base64")}`;
  } catch {
    return null;
  }
}

function siteHost(): string {
  try {
    return new URL(SITE.url).host;
  } catch {
    return "nonamehub.fyi";
  }
}

export default async function OG() {
  const logoUrl = await getLogoDataUri();
  const host = siteHost();

  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          background:
            "radial-gradient(circle at 50% 40%, #1a0d2e 0%, #0a0a12 70%)",
          color: "white",
          fontFamily: "sans-serif",
          padding: 60,
        }}
      >
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={logoUrl}
            width={90}
            height={90}
            alt=""
            style={{ marginBottom: 36 }}
          />
        )}

        <div
          style={{
            fontSize: 92,
            fontWeight: 800,
            letterSpacing: "-0.03em",
            lineHeight: 1,
          }}
        >
          NoNameHub
        </div>

        <div
          style={{
            fontSize: 34,
            color: "#8b5cf6",
            marginTop: 26,
            fontWeight: 600,
          }}
        >
          Roblox Scripts, Models &amp; UI
        </div>

        <div
          style={{
            width: 320,
            height: 2,
            background: "#8b5cf6",
            opacity: 0.35,
            marginTop: 54,
          }}
        />

        <div style={{ fontSize: 22, color: "#71717a", marginTop: 38 }}>
          {host}
        </div>
      </div>
    ),
    size,
  );
}